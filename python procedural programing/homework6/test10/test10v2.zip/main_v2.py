from syunik_itc import *

print(simple_numbers(0), "\n")
print(simple_numbers(8), "\n")
print(simple_numbers(97))

print(quad_equation(5, 20, 10))

print(float_to_ratio(4.2))
print(float_to_ratio(3.5))



print(gcd(252, 105))
print(gcd(147, 105))
print(gcd(270, 192))


print(points_distance([23.5, 67.5], [25.5, 69.5]))

print(cylinder(3, 5))

print(sphere(5))

print(radian(90))

print(polygon(2,3))