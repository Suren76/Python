from syunik_itc import *

print(simple_numbers(0))
print(simple_numbers(8))
print(simple_numbers(97))
print("\n")

print(quad_equation(5, 20, 10))
print("\n")

print(float_to_ratio(4.2))
print(float_to_ratio(3.5))
print("\n")


print(gcd(252, 105))
print(gcd(147, 105))
print(gcd(270, 192))
print("\n")


print(points_distance([23.5, 67.5], [25.5, 69.5]))
print("\n")

print(cylinder(3, 5))
print("\n")

print(sphere(5))
print("\n")

print(radian(90))
print("\n")

print(polygon(2, 3))
print("\n")
